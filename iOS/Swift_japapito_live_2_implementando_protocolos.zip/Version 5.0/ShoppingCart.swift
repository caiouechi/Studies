//
//  ShoppingCart.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class ShoppingCart: Orders {
    var cartID: Int?
    var productID: Int?
    var quantity: Int?
    var dateAdded: Int?
    
    
    override func displayData() -> String{
        var returnVariable = "";
        
        returnVariable = "ShoppingCart properties" + "\n"
        //ShoppingCart
        if self.cartID != nil {returnVariable += "cartID: \(self.cartID!) \n"}
        if self.productID != nil {returnVariable += "productID: \(self.productID!) \n"}
        if self.dateAdded != nil {returnVariable += "dateAdded: \(self.dateAdded!) \n"}
        
        //Orders
        if self.orderID != nil {returnVariable += "orderID: \(self.orderID!) \n"}
        if self.dateCreated != nil {returnVariable += "dateCreated: " + self.dateCreated! + "\n"}
        if self.dateShipped != nil {returnVariable += "dateShipped: " + self.dateShipped! + "\n"}
        if self.status != nil {returnVariable += "status: " + self.status! + "\n"}
        
        //Customer
        returnVariable += "customerID: " + self.customerID! + "\n"
        if self.customerName != nil {returnVariable += "customerName: " + self.customerName! + "\n"}
        if self.address != nil {returnVariable += "address: " + self.address! + "\n"}
        if self.email != nil {returnVariable += "email: " + self.email! + "\n"}
        if self.creditCardInfo != nil {returnVariable += "creditCardInfo: " + self.creditCardInfo! + "\n"}
        if self.shippingInfo != nil {       returnVariable += "shippingInfo: " + self.shippingInfo! + "\n"}
        
        //User
        returnVariable += "  userID: " + self.userID! + "\n"
        if self.password != nil {returnVariable += "  password" + self.password! + "\n"}
        if self.loginStatus != nil {returnVariable += "  loginStatus" + self.loginStatus! + "\n"}
        
        return returnVariable;
    }
    
    
    override init() {
        cartID = 0
        productID = 0
        quantity = 0
        dateAdded = 0
        super.init()
    }
    
    init(pCartID:Int, pProductID: Int, pQuantity: Int, pDateAdded:Int, pOrderID:Int, pShippingID: String, pCustomerID: String,pUserID: String) {
        self.cartID = pCartID
        self.productID = pProductID
        self.quantity = pQuantity
        self.dateAdded = pDateAdded
        super.init(pOrderID: pOrderID, pCustomerID: pCustomerID,pUserID: pUserID)

        
    }
    
    func addCartItem() {
        
    }
    
    func updateQuantity() {
        
    }
    
    func viewCardDetails() {
        
    }
    
    func checkOut() {
        
    }
}
