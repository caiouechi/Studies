package com.example.macstudent.midtermrecommended;

/**
 * 0 = first nav
 * 1 = second nav
 * 2 = third nav
 */
public class GlobalClass {
    public static int ActivitySelected = 0;
    public static String queryString = "";
}
