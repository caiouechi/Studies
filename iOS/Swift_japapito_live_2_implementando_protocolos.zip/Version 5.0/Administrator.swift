//
//  Administrator.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class Administrator: User {
    
   override func displayData() -> String {
        var returnVariable = "";
        
        returnVariable = "Printing Administrator properties" + "\n"
        returnVariable += "adminName: " + self.adminName! + "\n"
        returnVariable += "email: " + self.email! + "\n"
        returnVariable += "  userID: " + self.userID! + "\n"
        
        if self.password != nil {returnVariable += "  password" + self.password! + "\n"}
        if self.loginStatus != nil {returnVariable += "  loginStatus" + self.loginStatus! + "\n"}
   
        return returnVariable;
    }
    
    
    var adminName : String?
    var email : String?
 
    
    override init() {
        self.adminName = ""
        self.email = ""
        super.init()
    }
    
    func updateCatalog() -> Bool {
        return true
    }
    
    init(aName: String, aEmail: String,cUserID: String) {
        self.adminName = aName
        self.email = aEmail
        super.init(userID: cUserID)
    }
}
