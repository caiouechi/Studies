//
//  main.swift
//  SwiftProject
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

print("Hello, World!")

