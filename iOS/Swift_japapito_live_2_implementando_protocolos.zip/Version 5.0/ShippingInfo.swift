//
//  ShippingInfo.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class ShippingInfo: Orders {

    var shippingType: String?
    var shippingCost: Int?
    var shippingRegionID: Int?
    
    override func displayData() -> String{
        var returnVariable = "";
        
        returnVariable = "ShippinngInfo properties" + "\n"
        //ShippingInfo
        if self.shippingType != nil {returnVariable += "shippingType: \(self.shippingType!) \n"}
        if self.shippingCost != nil {returnVariable += "shippingCost: \(self.shippingCost!) \n"}
        if self.shippingRegionID != nil {returnVariable += "shippingRegionID: \(self.shippingRegionID!) \n"}
  
        //Orders
        if self.orderID != nil {returnVariable += "orderID: \(self.orderID!) \n"}
        if self.dateCreated != nil {returnVariable += "dateCreated: " + self.dateCreated! + "\n"}
        if self.dateShipped != nil {returnVariable += "dateShipped: " + self.dateShipped! + "\n"}
        if self.status != nil {returnVariable += "status: " + self.status! + "\n"}
        
        //Customer
        returnVariable += "customerID: " + self.customerID! + "\n"
        if self.customerName != nil {returnVariable += "customerName: " + self.customerName! + "\n"}
        if self.address != nil {returnVariable += "address: " + self.address! + "\n"}
        if self.email != nil {returnVariable += "email: " + self.email! + "\n"}
        if self.creditCardInfo != nil {returnVariable += "creditCardInfo: " + self.creditCardInfo! + "\n"}
        if self.shippingInfo != nil {       returnVariable += "shippingInfo: " + self.shippingInfo! + "\n"}
        
        //User
        returnVariable += "  userID: " + self.userID! + "\n"
        if self.password != nil {returnVariable += "  password" + self.password! + "\n"}
        if self.loginStatus != nil {returnVariable += "  loginStatus" + self.loginStatus! + "\n"}
        
        return returnVariable;
    }
    
    override init() {

        self.shippingType = ""
        self.shippingCost = 0
        self.shippingRegionID = 0
        super.init()
    }
    
    init(sShippingID: String, sShippingType:String, sShippingCost: Int, sShippingRegionID: Int, pOrderID: Int, pCustomerID: String,pUserID: String) {

        self.shippingType = sShippingType
        self.shippingCost = sShippingCost
        self.shippingRegionID = sShippingRegionID
            super.init(pOrderID: pOrderID, pCustomerID: pCustomerID,pUserID: pUserID)
    }
    
    func updateShippingInfo() {
        
    }
}
