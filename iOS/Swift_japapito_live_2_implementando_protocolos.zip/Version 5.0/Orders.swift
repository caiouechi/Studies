//
//  Orders.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class Orders: Customer {
   
    var orderID: Int?
    var dateCreated: String?
    var dateShipped: String?
    var status: String?
    //Removed shippingID because we used Heritage
    //var shippingID: String?
    
    override func displayData() -> String {
        var returnVariable = "";
        
        returnVariable = "Order properties" + "\n"

        //Orders
        if self.orderID != nil {returnVariable += "orderID: \(self.orderID!) \n"}
        if self.dateCreated != nil {returnVariable += "dateCreated: " + self.dateCreated! + "\n"}
        if self.dateShipped != nil {returnVariable += "dateShipped: " + self.dateShipped! + "\n"}
        if self.status != nil {returnVariable += "status: " + self.status! + "\n"}
        
        //Customer
        returnVariable += "customerID: " + self.customerID! + "\n"
        if self.customerName != nil {returnVariable += "customerName: " + self.customerName! + "\n"}
        if self.address != nil {returnVariable += "address: " + self.address! + "\n"}
        if self.email != nil {returnVariable += "email: " + self.email! + "\n"}
        if self.creditCardInfo != nil {returnVariable += "creditCardInfo: " + self.creditCardInfo! + "\n"}
        if self.shippingInfo != nil {       returnVariable += "shippingInfo: " + self.shippingInfo! + "\n"}
        
        //User
        returnVariable += "  userID: " + self.userID! + "\n"
        if self.password != nil {returnVariable += "  password" + self.password! + "\n"}
        if self.loginStatus != nil {returnVariable += "  loginStatus" + self.loginStatus! + "\n"}
        
        return returnVariable;
    }
    
    override init() {
        self.orderID = 0
        self.dateCreated = ""
        self.dateShipped = ""
        self.status = ""
        //self.shippingID = ""
        super.init()
    }
    
    init(pOrderID:Int, pDateCreated:String, pDateShipped:String, pStatus: String, pCustomerID: String,pUserID: String) {
        self.orderID = pOrderID
        self.dateCreated = pDateCreated
        self.dateShipped = pDateShipped
        self.status = pStatus
        
        
        super.init(pCustomerID: pCustomerID,pUserID: pUserID)
    }
    
    init(pOrderID:Int, pCustomerID: String,pUserID: String){
        self.orderID = pOrderID
        super.init(pCustomerID: pCustomerID, pUserID: pUserID)
    }
    
    func placeOrder() {
        
    }
}
