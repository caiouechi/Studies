//
//  OrderDetails.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class OrderDetails: Orders
{
    var orderId: Int?
    var productId: Int?
    var productName: String?
    var quantity: Int?
    var unitCost: Float?
    var subtotal: Float?
    
    override init() {
        self.orderId = 0
        self.productId = 0
        self.productName = ""
        self.quantity = 0
        self.unitCost = 0
        self.subtotal = 0
        super.init()
    }
    
    override func displayData() -> String {
        var returnVariable = "";
        
        returnVariable = "Order detail properties" + "\n"
        if self.orderId != nil {returnVariable += "orderId: \(self.orderId!) \n"}
        if self.productId != nil {returnVariable += "productId:  \(self.productId!) \n"}
        if self.productName != nil {returnVariable += "productName: " + self.productName! + "\n"}
        if self.quantity != nil {returnVariable += "quantity:  \(self.quantity!)  \n"}
        if self.quantity != nil {returnVariable += "quantity:  \(self.quantity!)  \n"}
        if self.unitCost != nil {returnVariable += "unitCost:  \(self.unitCost!)  \n"}
        if self.subtotal != nil {returnVariable += "subtotal:  \(self.subtotal!)  \n"}

        //Orders
        if self.dateCreated != nil {returnVariable += "dateCreated: " + self.dateCreated! + "\n"}
        if self.dateShipped != nil {returnVariable += "dateShipped: " + self.dateShipped! + "\n"}
        if self.status != nil {returnVariable += "status: " + self.status! + "\n"}
        
        //Customer
        returnVariable += "customerID: " + self.customerID! + "\n"
        if self.customerName != nil {returnVariable += "customerName: " + self.customerName! + "\n"}
        if self.address != nil {returnVariable += "address: " + self.address! + "\n"}
        if self.email != nil {returnVariable += "email: " + self.email! + "\n"}
        if self.creditCardInfo != nil {returnVariable += "creditCardInfo: " + self.creditCardInfo! + "\n"}
        if self.shippingInfo != nil {       returnVariable += "shippingInfo: " + self.shippingInfo! + "\n"}
        
        //User
        returnVariable += "  userID: " + self.userID! + "\n"
        if self.password != nil {returnVariable += "  password" + self.password! + "\n"}
        if self.loginStatus != nil {returnVariable += "  loginStatus" + self.loginStatus! + "\n"}
        
        return returnVariable;
    }
    
    init(oId: Int , oPId:Int , oPName:String , oQuantity:Int , oUCost:Float , oSubTotal:Float, pOrderID: Int, pCustomerID: String, pUserID: String)
    {
        self.orderId = oId
        self.productId = oPId
        self.productName = oPName
        self.quantity = oQuantity
        self.unitCost = oUCost
        self.subtotal = oSubTotal
        super.init(pOrderID: pOrderID, pCustomerID: pCustomerID,pUserID: pUserID)
    }
    
    func calcPrice() {
        
    }
}
