Thanks for downloading this theme!

Theme Name: Delicious
Theme URL: https://bootstrapmade.com/delicious-free-restaurant-bootstrap-theme/
Author: BootstrapMade.com
Author URL: https://bootstrapmade.com