//
//  InterfaceController.swift
//  FlightBooker WatchKit Extension
//
//  Created by Pulkit Kumar on 2019-03-11.
//  Copyright © 2019 Pulkit. All rights reserved.
//


import WatchKit
import Foundation
import WatchConnectivity



class InterfaceController: WKInterfaceController, WCSessionDelegate {
    
    var lastMessage: CFAbsoluteTime = 0

    @IBOutlet weak var lblResult: WKInterfaceLabel!
    
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    @IBAction func sendToIphone() {
        lblResult.setText("Sending data");
        self.sendIphoneMessage();
    }
    
    func sendIphoneMessage() {
        let currentTime = CFAbsoluteTimeGetCurrent()
        
        // if less than half a second has passed, bail out
        if lastMessage + 0.5 > currentTime {
            return
        }
        
        // send a message to the watch if it's reachable
        if (WCSession.default.isReachable) {
            // this is a meaningless message, but it's enough for our purposes
            // let message = ["liter": price, "cost" : lpk]
            let message = ["fromwatchos": "msgsent", "lpkc" : "lala", "speedc" : "lala", "distancec": "lala"]
              lblResult.setText("Sending data");
            WCSession.default.sendMessage(message, replyHandler: nil)
             lblResult.setText("Sending sent");
        }
        
        // update our rate limiting property
        lastMessage = CFAbsoluteTimeGetCurrent()
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        if WCSession.isSupported() {
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        lblResult.setText(String(message["pricec"] as! String))
        //lblResult.setText(String(message["second"] as! String))
        //WKInterfaceDevice().play(.click)
    }
    



 

}
