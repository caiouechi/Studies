//
//  ViewController.swift
//  FlightBooker
//
//  Created by Pulkit Kumar on 2019-03-11.
//  Copyright © 2019 Pulkit. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

class ViewController: UIViewController {

    @IBOutlet var startCity: UITextField!
    @IBOutlet var endCity: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func CheckFlights(_ sender: Any) {
        
        let start = startCity.text
        let end = endCity.text
        
        //FlyFrom = Starting airport
        //to = Landing airport
        //dateFrom = min Flying date
        //dateTo = max Flying date, so API will search for flights from dateFrom to dateTo, finding the best flights between these range of dates. This is NOT return date
        //sort = quality.  this gives best flight experience
        //limit = number of flights we want in the api call. Note, no way to paginate it.
        
        let URL =
        "https://api.skypicker.com/flights?flyFrom=\(start)&to=\(end)&dateFrom=18/04/2019&dateTo=18/04/2019&sort=quality&curr=CAD&partner=picky&max_stopovers=0&limit=10"
        
        
        Alamofire.request(URL).responseJSON {
            // 1. store the data from the internet in the
            // response variable
            response in
            // 2. get the data out of the variable
            guard let apiData = response.result.value else {
                print("Error getting data from the URL")
                return
            }
            print(apiData)
            
            // GET something out of the JSON response
            let jsonResponse = JSON(apiData)
        }
        
    }
    
}

