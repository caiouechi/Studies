//: Playground - noun: a place where people can play

import UIKit

var str = "FALA JAPAPITO MEU!!! BELEZINHA?"

print(str);

var lista = ["Esdruxula", "Proko", "kolizyon666"]

print("5","7","9", terminator: ";")


var tipoNumerico:Int = 99;

var tipoNulo:Int?? = 24;

if (tipoNulo == nil){
    print("Eh nulo");
}else {
    print("Nao eh nulo");
}

for _ in 1...5 {
    print("imprimindo o numero");
}

var valor:Double = 25.0;

for i in (stride(from: 1, to: 50, by: valor)) {
    print ("Deu errado");
}


var wisktonVariable = 20;

while wisktonVariable < 30{
    print("Valor da variavel wisk: ", wisktonVariable);
    wisktonVariable += 1;
}


var keiliane = "abc";

switch (keiliane) {
case "abc": print("keiliane");
default: print("eh obrigado a ter o valor default");
}


//fazer mais uma vez o stride
var contador:Int = 3;

for i in (stride(from: 1, to: 50, by: contador )){
    print(i);
}









