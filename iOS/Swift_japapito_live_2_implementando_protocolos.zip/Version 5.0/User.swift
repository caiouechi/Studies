//
//  User.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class User: IDisplay{
    var userID : String?
    var password : String?
    var loginStatus : String?
    
    func displayData() -> String {
        var returnVariable = "";
        
        returnVariable = "Printing User properties" + "\n"
        returnVariable += "userID: " + self.userID! + "\n"
        if self.password != nil {returnVariable += "password: " + self.password! + "\n"}
        if self.loginStatus != nil {returnVariable += "loginStatus: " + self.loginStatus! + "\n"}
       
        return returnVariable;
    }
    
    func verifyLogin() -> Bool {
        /*
         verification login
         */
        return true
    }
    
    
    
    init() {
        userID = ""
        //Default values
        password = "123456"
        loginStatus = "Active"
    }
    
    init(userID: String, pass: String, lstatus: String) {
        self.userID = userID
        self.password = pass
        self.loginStatus = lstatus
    }

    init(userID: String) {
        self.userID = userID
    }

}

