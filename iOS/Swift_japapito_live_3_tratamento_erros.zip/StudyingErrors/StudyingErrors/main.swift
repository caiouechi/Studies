//
//  main.swift
//  StudyingErrors
//
//  Created by Caio Uechi on 2018-02-11.
//  Copyright © 2018 Caio Uechi. All rights reserved.
//

import Foundation

print("Hello, World!")


var novoObject = PartidaCompetitivaCSGO();

do{
try novoObject.CompraDeArma(NomeArma: "AK-47");
}catch JAPAPITOErrors.ArmaInexistente{
    print("Arma inexistente")
}catch JAPAPITOErrors.JAPAPITOBunando{
    print("Problema japapito bunando")
}catch{
    print("Tratamento padrao")
}

