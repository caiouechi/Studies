//
//  Errors.swift
//  StudyingErrors
//
//  Created by Caio Uechi on 2018-02-11.
//  Copyright © 2018 Caio Uechi. All rights reserved.
//

import Foundation

public enum JAPAPITOErrors : Error {
    case JAPAPITOPinando
    case JAPAPITOBunando
    case ArmaInexistente
}

struct JogadorCSGO {
    var movimentacao : String
    var tiroArma: String
}
