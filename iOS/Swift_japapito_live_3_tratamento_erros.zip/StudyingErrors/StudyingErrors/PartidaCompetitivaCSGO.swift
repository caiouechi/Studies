//
//  PartidaCompetitivaCSGO.swift
//  StudyingErrors
//
//  Created by Caio Uechi on 2018-02-11.
//  Copyright © 2018 Caio Uechi. All rights reserved.
//

import Foundation

public class PartidaCompetitivaCSGO {
    var NumeroJogadores: Int
    var VelocidadeJogador: Int
    var ArmaComprada: String
    var ListaArmas = Dictionary<String, Int>()
    
    init(){
        self.NumeroJogadores = 10;
        self.VelocidadeJogador = 800;
        self.ArmaComprada = "AK-47";
        
        ListaArmas["AK-47"] = 2700
        ListaArmas["M4A4"] = 3100
        ListaArmas["HE"] = 300
    }
    
    func CompraDeArma(NomeArma: String) throws{
        
        guard let ArmaComprada = ListaArmas[NomeArma] else{
            throw JAPAPITOErrors.ArmaInexistente
        }
        
        if self.VelocidadeJogador < 500 {
            throw JAPAPITOErrors.JAPAPITOBunando
   
    }
    
    
       
    
    }
    
}
