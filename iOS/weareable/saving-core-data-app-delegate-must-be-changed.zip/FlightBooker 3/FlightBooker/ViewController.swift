//
//  ViewController.swift
//  FlightBooker
//
//  Created by Pulkit Kumar on 2019-03-11.
//  Copyright © 2019 Pulkit. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import CoreData

//DONT FORGET TO ADD THE CODE OF COREDATA IN THE APPDELEGATE.SWIFT FILE
class ViewController: UIViewController {
//DONT FORGET TO ADD THE CODE OF COREDATA IN THE APPDELEGATE.SWIFT FILE
    
    @IBOutlet weak var lblResult: UILabel!

    @IBAction func saveCoreData(_ sender: Any) {
        //DONT FORGET TO ADD THE CODE OF COREDATA IN THE APPDELEGATE.SWIFT FILE
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let entity = NSEntityDescription.entity(forEntityName: "Users", in: context)
        let newUser = NSManagedObject(entity: entity!, insertInto: context)
        
        
        newUser.setValue("Shashikant", forKey: "username")
        newUser.setValue("1234", forKey: "password")
        newUser.setValue("12", forKey: "age")
        
        do {
            
            try context.save()
            
        } catch {
            
            print("Failed saving")
        }
        
        
        
    }
    @IBAction func retrieveCoreData(_ sender: Any) {
        //DONT FORGET TO ADD THE CODE OF COREDATA IN THE APPDELEGATE.SWIFT FILE
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        //request.predicate = NSPredicate(format: "age = %@", "12")
        request.returnsObjectsAsFaults = false
        
        do {
            let result = try context.fetch(request)
            for data in result as! [NSManagedObject] {
                print(data.value(forKey: "username") as! String)
            }
            
        } catch {
            
            print("Failed")
        }
    }
    

    
    @IBOutlet weak var saveCoreData: UIButton!
    @IBOutlet var startCity: UITextField!
    @IBOutlet var endCity: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func CheckFlights(_ sender: Any) {
        
        let start = startCity.text
        let end = endCity.text
        
        //FlyFrom = Starting airport
        //to = Landing airport
        //dateFrom = min Flying date
        //dateTo = max Flying date, so API will search for flights from dateFrom to dateTo, finding the best flights between these range of dates. This is NOT return date
        //sort = quality.  this gives best flight experience
        //limit = number of flights we want in the api call. Note, no way to paginate it.
        
        let URL =
        "https://api.skypicker.com/flights?flyFrom=\(start)&to=\(end)&dateFrom=18/04/2019&dateTo=18/04/2019&sort=quality&curr=CAD&partner=picky&max_stopovers=0&limit=10"
        
        
        Alamofire.request(URL).responseJSON {
            // 1. store the data from the internet in the
            // response variable
            response in
            // 2. get the data out of the variable
            guard let apiData = response.result.value else {
                print("Error getting data from the URL")
                return
            }
            print(apiData)
            
            // GET something out of the JSON response
            let jsonResponse = JSON(apiData)
        }
        
    }
    
}

