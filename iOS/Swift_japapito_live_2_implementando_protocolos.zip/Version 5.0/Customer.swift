//
//  Customer.swift
//  Day6
//
//  Created by Kuljeet Singh on 2018-02-05.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class Customer : User {
    //customerID is gonna be the link between Shopping Cart entity, Orders entity with Customer entity
    //every customer has userID, but not the reverse
    var customerID: String?
    var customerName : String?
    var address : String?
    var email : String?
    var creditCardInfo : String?
    var shippingInfo : String?
    
    override func displayData() -> String {
        var returnVariable = "";

        returnVariable = "Printing Customer properties" + "\n"
        returnVariable += "customerID: " + self.customerID! + "\n"
        
        if self.customerName != nil {returnVariable += "customerName: " + self.customerName! + "\n"}
        if self.address != nil {returnVariable += "address: " + self.address! + "\n"}
        if self.email != nil {returnVariable += "email: " + self.email! + "\n"}
        if self.creditCardInfo != nil {returnVariable += "creditCardInfo: " + self.creditCardInfo! + "\n"}
        if self.shippingInfo != nil {returnVariable += "shippingInfo: " + self.shippingInfo! + "\n"}
        if self.userID != nil {returnVariable += "  userID: " + self.userID! + "\n"}
        if self.password != nil {returnVariable += "  password" + self.password! + "\n"}
        if self.loginStatus != nil {returnVariable += "  loginStatus" + self.loginStatus! + "\n"}
        
        return returnVariable;
    }
    
    override init() {
        self.customerID = ""
        self.customerName = ""
        self.address = ""
        self.email = ""
        self.creditCardInfo = ""
        self.shippingInfo = ""
        
        super.init()
    }
    
    init(pCustomerID: String, pCustomerName: String, pAddress: String, pEmail: String, pCreditCardInfo: String, pShippingInfo: String, pUserID: String) {
        self.customerID = pCustomerID
        self.customerName = pCustomerName
        self.address = pAddress
        self.email = pEmail
        self.creditCardInfo = pCreditCardInfo
        self.shippingInfo = pShippingInfo
        
        super.init(userID: pUserID)
    }
    
    init(pCustomerID: String, pUserID: String){
        self.customerID = pCustomerID
        super.init(userID: pUserID)
    }
    
    
    func register() {
        
    }
    
    func login() {
        
    }
    
    func updateProfile() {
        
    }
    
    
}
