//
//  ViewController.swift
//  FlightBooker
//
//  Created by Pulkit Kumar on 2019-03-11.
//  Copyright © 2019 Pulkit. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire
import WatchConnectivity


class ViewController: UIViewController, WCSessionDelegate {
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        lblResult.text = (String(message["fromwatchos"] as! String))
        //lblResult.setText(String(message["second"] as! String))
        //WKInterfaceDevice().play(.click)
    }
    
    
            var lastMessage: CFAbsoluteTime = 0
    
    @IBOutlet weak var lblResult: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        if (WCSession.isSupported()) {
            let session = WCSession.default
            session.delegate = self as! WCSessionDelegate
            session.activate()
        }
        
        
        // update our rate limiting property
//        lastMessage = CFAbsoluteTimeGetCurrent()
        
    }
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) {
        
    }
    
    func sessionDidDeactivate(_ session: WCSession) {
        
    }
    

    @IBAction func sendToWatchClick(_ sender: Any) {
        lblResult.text = ("Sending data");
        self.sendWatchMessage();
        
    }
    
    
    func sendWatchMessage() {
        let currentTime = CFAbsoluteTimeGetCurrent()
        
        // if less than half a second has passed, bail out
        if lastMessage + 0.5 > currentTime {
            return
        }
        
        // send a message to the watch if it's reachable
        if (WCSession.default.isReachable) {
            // this is a meaningless message, but it's enough for our purposes
            // let message = ["liter": price, "cost" : lpk]
            let message = ["pricec": "lala", "lpkc" : "lala", "speedc" : "lala", "distancec": "lala"]
            lblResult.text = ("before sending");
            WCSession.default.sendMessage(message, replyHandler: nil)
            lblResult.text = ("Data sent");
        }
        
        // update our rate limiting property
        lastMessage = CFAbsoluteTimeGetCurrent()
    }
    

    @IBOutlet var startCity: UITextField!
    @IBOutlet var endCity: UITextField!


    @IBAction func CheckFlights(_ sender: Any) {
        
        let start = startCity.text
        let end = endCity.text
        
        //FlyFrom = Starting airport
        //to = Landing airport
        //dateFrom = min Flying date
        //dateTo = max Flying date, so API will search for flights from dateFrom to dateTo, finding the best flights between these range of dates. This is NOT return date
        //sort = quality.  this gives best flight experience
        //limit = number of flights we want in the api call. Note, no way to paginate it.
        
        let URL = "https://api.skypicker.com/flights?flyFrom=\(start)&to=\(end)&dateFrom=18/04/2019&dateTo=18/04/2019&sort=quality&curr=CAD&partner=picky&max_stopovers=0&limit=10"
        
        
        Alamofire.request(URL).responseJSON {
            // 1. store the data from the internet in the
            // response variable
            response in
            // 2. get the data out of the variable
            guard let apiData = response.result.value else {
                print("Error getting data from the URL")
                return
            }
            print(apiData)
            
            // GET something out of the JSON response
            let jsonResponse = JSON(apiData)
        }
        
    }
    
}

